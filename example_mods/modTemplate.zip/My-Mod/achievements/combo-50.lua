-- Attached to the achievement "combo-50" (same file name as combo-50.json).
-- It runs in every song while the achievement is still locked; achievementId is "combo-50".

function goodNoteHit(id, direction, noteType, isSustain)
	if botPlay then return end -- botplay shouldn't earn achievements
	if getProperty('combo') >= 50 then
		unlockAchievement(achievementId)
	end
end
